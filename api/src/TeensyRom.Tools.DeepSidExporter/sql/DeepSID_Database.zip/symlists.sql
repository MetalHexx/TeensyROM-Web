-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: chordian.net.mysql.service.one.com:3306
-- Generation Time: May 18, 2024 at 06:40 AM
-- Server version: 10.6.15-MariaDB-1:10.6.15+maria~ubu2204
-- PHP Version: 8.1.2-1ubuntu2.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chordian_net_deepsid`
--

-- --------------------------------------------------------

--
-- Table structure for table `symlists`
--

CREATE TABLE `symlists` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `folder_id` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `file_id` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `sidname` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `subtune` smallint(5) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Indexes for table `symlists`
--
ALTER TABLE `symlists`
  ADD PRIMARY KEY (`id`),
  ADD KEY `folder_id` (`folder_id`,`file_id`);

--
-- AUTO_INCREMENT for table `symlists`
--
ALTER TABLE `symlists`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
